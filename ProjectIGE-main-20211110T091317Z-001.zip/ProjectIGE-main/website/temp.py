def data(x,y):
    print(x)
    print(y)