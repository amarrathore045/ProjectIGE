from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os 
import time
import datetime
from selenium.webdriver import ChromeOptions, Chrome


class bot: 
    def __init__(self, username, password): 
        self.username = username
        self.password = password
        self.driver = webdriver.Chrome()

        self.by = By
        self.ec = EC
        self.webDriverWait = WebDriverWait

        time.sleep(1)
        self.login()

    def login(self):
        self.driver.get('https://www.instagram.com/accounts/login/')

        self.webDriverWait(self.driver, 20).until(self.ec.presence_of_element_located((self.by.NAME, 'username')))
        self.webDriverWait(self.driver, 20).until(self.ec.presence_of_element_located((self.by.NAME, 'password')))
        self.webDriverWait(self.driver, 20).until(self.ec.element_to_be_clickable((self.by.XPATH, "//*[@id='loginForm']/div/div[3]")))

        self.driver.find_element_by_name('username').send_keys(self.username)
        self.driver.find_element_by_name('password').send_keys(self.password)
        self.driver.find_element_by_xpath("//*[@id='loginForm']/div/div[3]").click()
        
        time.sleep(5)

        self.driver.get('https://www.instagram.com/'+self.username)

        followers = self.driver.find_element_by_xpath("//*[@id='react-root']/section/main/div/header/section/ul/li[2]/a/span").text
        following = self.driver.find_element_by_xpath("//*[@id='react-root']/section/main/div/header/section/ul/li[3]/a/span").text
        self.driver.find_element_by_xpath("//*[@id='react-root']/section/main/div/header/section/ul/li[2]/a/span").click()
        print(followers)
        print(following)

        i, k = 1, 1
        time.sleep(5)
        while (k <= int(followers)):
            currentUser = self.driver.find_element_by_xpath("/html/body/div[6]/div/div/div[2]/ul/div/li[{}]".format(i))
            name = self.driver.find_element_by_css_selector(".notranslate").text

            print(name)

            self.driver.execute_script("arguments[0].scrollIntoView()", currentUser)
            i += 1
            k += 1
            if k % 8 == 0:
                time.sleep(2)


        """
        n_scrolls = 2
        for j in range(0, n_scrolls):
            self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
            time.sleep(5)
        """

        #self.webDriverWait(self.driver, 20).until(self.ec.element_to_be_clickable((self.by.XPATH, "//*[@id='react-root']/section/main/div/div/div/div/button")))
        #self.driver.find_element_by_xpath("//*[@id='react-root']/section/main/div/div/div/div/button").click()

        #self.webDriverWait(self.driver, 20).until(self.ec.element_to_be_clickable((self.by.XPATH, "/html/body/div[6]/div/div/div/div[3]/button[2]")))
        #self.driver.find_element_by_xpath("/html/body/div[6]/div/div/div/div[3]/button[2]").click()
    opts = ChromeOptions()
    opts.add_experimental_option("detach", True)
    driver = Chrome(chrome_options=opts)