from selenium import webdriver
driver=webdriver.Chrome()
driver.get("https://www.instagram.com/")
driver.find_elements_by_css_selector('username').send_keys("dhruvagrawal_31")
driver.find_elements_by_name("password").send_keys("mahal@123")
driver.find_elements_by_xpath("//*[@id='loginForm']/div/div[1]/div/label/input").click()