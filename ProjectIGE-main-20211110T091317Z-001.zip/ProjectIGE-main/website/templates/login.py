from selemium import webdriver
from selenium.commmon.ec import EC
import time 
import datetime

class bot:
    def __init__(username, password):
        self.driver = webdriver
        self.username = username
        self.password = password
        self.ec = EC
        
    def login(self):
        self.driver.get('http://www.instagram.com')
